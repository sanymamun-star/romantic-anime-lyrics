# Romantic Anime Lyrics — Remotion starter

## Included
- 1080x1920, 30 FPS, 678-frame (22.6s) composition.
- Supplied audio and the two supplied character references (white background edge-keyed to transparent PNG).
- Timestamped lyric overlays, cinematic gradient environments, gentle camera drift and scene changes.

## Run
Requires Node.js 18. If using Android, use a cloud development environment with a terminal (for example, a browser-based Codespace); the phone itself does not need to run the renderer.

```bash
npm install
npm run dev
```

Render:
```bash
npm run render
```
Output: `out/romantic-lyrics.mp4`

## Important production notes
- Audio file is 22.625s AAC audio in an `.mp3` container. Remotion/FFmpeg will decode it; output is trimmed to 678 frames (22.6s).
- The provided character references are full-body character sheets, not scene-specific illustrations. This starter animates them over designed cinematic backgrounds; it does not yet create new poses or realistic illustrated locations. For a premium final cut, replace the two transparent PNGs with scene-specific Anime Illustration artwork while preserving the same character identity.
- Scene changes are composed from lyric beats; the lyric timestamps are converted to frames at 30 FPS. A 1-frame rounding tolerance is inherent when converting decimal seconds to a 30 FPS timeline.
- This project has not been rendered in this environment; run the commands above and inspect the MP4 before publishing.
