import React from 'react';
import {Composition} from 'remotion';
import {RomanticLyrics} from './Video';
export const Root: React.FC = () => <Composition id="RomanticLyrics" component={RomanticLyrics} durationInFrames={678} fps={30} width={1080} height={1920} />;
