import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, useCurrentFrame, useVideoConfig, staticFile} from 'remotion';

type SceneData={start:number;end:number;title:string;bg1:string;bg2:string;place:string;female?:boolean;male?:boolean;layout:'wide'|'close'|'pair'|'solo'};
const scenes:SceneData[]=[
 {start:0,end:84,title:'INTRO',bg1:'#182c3a',bg2:'#d99b70',place:'CITY LAKE • DUSK',female:true,male:true,layout:'wide'},
 {start:84,end:174,title:'EYES',bg1:'#392b42',bg2:'#d79d91',place:'SOFT EVENING LIGHT',female:true,layout:'close'},
 {start:174,end:246,title:'WORDS',bg1:'#243c4a',bg2:'#d4a17d',place:'RIVERSIDE WALK',female:true,male:true,layout:'pair'},
 {start:246,end:354,title:'HEARTBEAT',bg1:'#273747',bg2:'#c98e79',place:'WATERFRONT',female:true,male:true,layout:'pair'},
 {start:354,end:453,title:'DREAM',bg1:'#302c49',bg2:'#e4ad91',place:'CITY LIGHTS',male:true,layout:'solo'},
 {start:453,end:519,title:'ARRIVAL',bg1:'#304c50',bg2:'#e4bd91',place:'PARK PATH',female:true,male:true,layout:'pair'},
 {start:519,end:678,title:'GOLDEN HOUR',bg1:'#5a3c43',bg2:'#f0c18b',place:'GOLDEN LAKE',female:true,male:true,layout:'wide'}
];
const lyrics=[
 {s:84,e:120,t:'Uski Aankhon'}, {s:123,e:174,t:'Mein Faila Kajal'},
 {s:177,e:213,t:'Baaton Se'}, {s:216,e:246,t:'Karti Ghayal'},
 {s:249,e:285,t:'Sanson Mein'}, {s:288,e:354,t:'Uska Hi Hai Naam'},
 {s:387,e:426,t:'Meri Neenden'}, {s:429,e:453,t:'Udi Hai'},
 {s:456,e:480,t:'Jab Se'}, {s:483,e:519,t:'Tu Aa Gayi'},
 {s:522,e:549,t:'Jeevan Mein'}, {s:552,e:591,t:'Roshan Kar'},
 {s:594,e:615,t:'De Tu'}, {s:618,e:678,t:'Mujhko Aaj'}
];
const clamp=(v:number)=>Math.max(0,Math.min(1,v));
const Backdrop:React.FC<{a:string;b:string;frame:number;place:string}> = ({a,b,frame,place})=>{
 const drift=interpolate(frame,[0,678],[0,90]);
 return <AbsoluteFill style={{background:`linear-gradient(160deg, ${a} 0%, #243744 48%, ${b} 100%)`,overflow:'hidden'}}>
  <div style={{position:'absolute',inset:'42% -10% -10%',background:'linear-gradient(180deg,rgba(255,220,180,.08),rgba(5,18,29,.88))',borderRadius:'50% 50% 0 0',transform:`translateX(${Math.sin(frame/80)*18}px)`}}/>
  <div style={{position:'absolute',left:'-10%',right:'-10%',top:'49%',height:5,background:'rgba(255,221,180,.24)',filter:'blur(5px)'}}/>
  {Array.from({length:14},(_,i)=><div key={i} style={{position:'absolute',left:`${(i*83+12)%100}%`,top:`${42+(i*17)%42}%`,width: i%3===0?12:6,height:i%3===0?12:6,borderRadius:50,background:'rgba(255,224,190,.42)',filter:'blur(3px)',transform:`translateY(${Math.sin(frame/22+i)*9}px)`}}/>)}
  <div style={{position:'absolute',top:110,left:70,color:'rgba(255,239,220,.48)',fontSize:19,letterSpacing:7,fontFamily:'Arial'}}>{place}</div>
  <div style={{position:'absolute',right:-120,top:260,width:560,height:560,borderRadius:'50%',background:'rgba(255,210,158,.10)',filter:'blur(70px)'}}/>
 </AbsoluteFill>
};
const Character:React.FC<{kind:'female'|'male';frame:number;layout:string}> = ({kind,frame,layout})=>{
 const isF=kind==='female';
 const src=staticFile(isF?'female.png':'male.png');
 const scale=interpolate(frame,[0,678],[1.02,1.12]);
 const width=isF?(layout==='close'?'76%':layout==='wide'?'48%':'54%'):(layout==='wide'?'45%':'48%');
 const left=isF?(layout==='pair'?'8%':layout==='wide'?'9%':'12%'):(layout==='pair'?'49%':'48%');
 const y=isF?(layout==='close'?'18%':'25%'):'27%';
 return <Img src={src} style={{position:'absolute',width,left,top:y,height:'auto',objectFit:'contain',transform:`scale(${scale}) translateY(${Math.sin(frame/35)*7}px)`,transformOrigin:'center bottom',filter:'drop-shadow(0 28px 32px rgba(0,0,0,.28))'}}/>;
};
const Lyric:React.FC<{text:string;duration:number}> = ({text,duration})=>{
 const f=useCurrentFrame();
 const local=f;
 const opacity=interpolate(f,[0,7,Math.max(7,duration-7),duration],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 const y=interpolate(local,[0,12],[34,0],{extrapolateRight:'clamp'});
 const scale=interpolate(local,[0,12],[.97,1],{extrapolateRight:'clamp'});
 return <div style={{position:'absolute',left:70,right:70,bottom:330,textAlign:'center',opacity,transform:`translateY(${y}px) scale(${scale})`,fontFamily:'Georgia,serif',fontSize:58,fontWeight:600,color:'#fff8ed',letterSpacing:1.2,textShadow:'0 4px 18px rgba(0,0,0,.85),0 0 24px rgba(255,213,169,.3)'}}>{text}</div>;
};
const Scene:React.FC<{scene:SceneData}> = ({scene})=>{
 const f=useCurrentFrame();
 return <AbsoluteFill>
  <Backdrop a={scene.bg1} b={scene.bg2} frame={f} place={scene.place}/>
  {scene.male&&<Character kind="male" frame={f} layout={scene.layout}/>}
  {scene.female&&<Character kind="female" frame={f} layout={scene.layout}/>}
  <div style={{position:'absolute',inset:0,background:'linear-gradient(180deg,rgba(0,0,0,.02) 45%,rgba(0,0,0,.48) 100%)'}}/>
 </AbsoluteFill>
};
export const RomanticLyrics:React.FC=()=>{
 const frame=useCurrentFrame(); const {fps}=useVideoConfig();
 const active=scenes.find(s=>frame>=s.start&&frame<s.end)??scenes[scenes.length-1];
 const fade=interpolate(frame,[0,18,660,678],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <AbsoluteFill style={{background:'#101923',opacity:fade}}>
  <Sequence from={active.start} durationInFrames={active.end-active.start}><Scene scene={active}/></Sequence>
  <Audio src={staticFile('song.mp3')} volume={1}/>
  {lyrics.map((l,i)=><Sequence key={i} from={l.s} durationInFrames={l.e-l.s}><Lyric text={l.t} duration={l.e-l.s}/></Sequence>)}
 </AbsoluteFill>;
};
